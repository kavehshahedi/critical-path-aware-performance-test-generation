from typing import Optional, List, Dict, Tuple
from dataclasses import dataclass
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt

from tmll.common.models.experiment import Experiment
from tmll.common.models.output import Output
from tmll.ml.modules.base_module import BaseModule
from tmll.tmll_client import TMLLClient
import pandas as pd
import cxxfilt


@dataclass
class FunctionCall:
    """Represents a function call with timing and hierarchy information"""
    entry_id: str
    function_name: str
    start_time: pd.Timestamp
    end_time: pd.Timestamp
    parent_id: str
    thread_id: str
    children: List['FunctionCall'] = None
    depth: int = 0

    def __post_init__(self):
        if self.children is None:
            self.children = []

    @property
    def duration_ns(self) -> int:
        """Duration in nanoseconds"""
        return int((self.end_time - self.start_time).total_seconds() * 1e9)

    @property
    def duration_us(self) -> float:
        """Duration in microseconds"""
        return self.duration_ns / 1000.0

    @property
    def self_time_ns(self) -> int:
        """Self time excluding children"""
        children_time = sum(child.duration_ns for child in self.children)
        return max(0, self.duration_ns - children_time)


class CriticalPathAnalysisModule(BaseModule):

    def __init__(self, client: TMLLClient, experiment: Experiment,
                 outputs: Optional[List[Output]] = None, **kwargs) -> None:
        """
        Initialize the Critical Path Analysis module.

        :param client: The TMLL client for data communication
        :type client: TMLLClient
        :param experiment: The experiment to analyze
        :type experiment: Experiment
        :param outputs: Optional list of outputs to analyze. If None, uses BASE_OUTPUTS
        :type outputs: Optional[List[Output]]
        :param kwargs: Additional keyword arguments
        """
        super().__init__(client, experiment)

        self.flamechart = None

        # Critical path analysis attributes
        self.function_calls: Dict[str, FunctionCall] = {}
        self.root_calls: Dict[str, List[FunctionCall]] = defaultdict(list)
        self.thread_calls: Dict[str, List[FunctionCall]] = defaultdict(list)
        self._analysis_results = None

        self.logger.info(f"Initialized Critical Path Analysis Module for experiment: {experiment.name}")

        outputs = experiment.find_outputs(["callstack", "flame", "chart"])
        self._process(outputs, **kwargs)

    def _format_time_with_unit(self, time_ns: float) -> str:
        """
        Format time with appropriate unit based on magnitude.

        :param time_ns: Time value in nanoseconds
        :type time_ns: float
        :return: Formatted time string with appropriate unit
        :rtype: str
        """
        abs_time = abs(time_ns)

        if abs_time < 1000:  # < 1 μs
            return f"{time_ns:.1f}ns"
        elif abs_time < 1_000_000:  # < 1 ms
            return f"{time_ns / 1000:.1f}μs"
        elif abs_time < 1_000_000_000:  # < 1 s
            return f"{time_ns / 1_000_000:.1f}ms"
        else:  # >= 1 s
            return f"{time_ns / 1_000_000_000:.2f}s"

    def _get_best_time_unit_for_range(self, max_time_us: float) -> Tuple[float, str]:
        """
        Determine the best time unit and conversion factor for a given time range.

        :param max_time_us: Maximum time value in the range (in microseconds)
        :type max_time_us: float
        :return: Tuple of (conversion_factor, unit_label)
        :rtype: Tuple[float, str]
        """
        max_time_ns = max_time_us * 1000

        if max_time_ns < 1000:  # < 1 μs
            return 1000, "ns"  # Convert μs to ns
        elif max_time_ns < 1_000_000:  # < 1 ms
            return 1, "μs"  # Keep in μs
        elif max_time_ns < 1_000_000_000:  # < 1 s
            return 0.001, "ms"  # Convert μs to ms
        else:  # >= 1 s
            return 0.000001, "s"  # Convert μs to s

    def _process(self, outputs: Optional[List[Output]] = None, **kwargs) -> None:
        """
        Process the flame chart data.

        This method fetches and processes the CallStack Flame Chart data
        with minimal preprocessing to preserve the original call stack structure.

        :param kwargs: Additional processing parameters
        """
        super()._process(outputs=outputs, **kwargs)

    def _post_process(self, **kwargs) -> None:
        """
        Post-process the flame chart data and prepare for critical path analysis.
        """
        if self.dataframes is not None:
            self.flamechart = next(iter(self.dataframes.values())).copy()
            self.flamechart = self.flamechart[self.flamechart["label"].notna()]

            def safe_demangle(x):
                try:
                    return cxxfilt.demangle(x)
                except Exception:
                    return x
            self.flamechart["label"] = self.flamechart["label"].apply(safe_demangle)
            self.flamechart["entry_id"] = self.flamechart["entry_id"].astype(int)

            # Remove duplicate entries (exact identical rows)
            self.flamechart = self.flamechart.drop_duplicates()

            # Initialize critical path analysis structures
            self._build_call_hierarchy()

            self.logger.info(f"Processed {len(self.flamechart)} function calls for critical path analysis")

    def _build_call_hierarchy(self):
        """Build parent-child relationships from the flame chart data"""
        if self.flamechart is None:
            self.logger.warning("No flame chart data available for hierarchy building")
            return

        self.logger.info("Building call hierarchy...")

        # Reset data structures
        self.function_calls = {}
        self.root_calls = defaultdict(list)
        self.thread_calls = defaultdict(list)

        # Sort by start time for proper processing
        sorted_df = self.flamechart.sort_values('timestamp')

        # Create FunctionCall objects with proper ID handling
        for idx, row in sorted_df.iterrows():
            # Use a combination of entry_id and timestamp for unique identification
            unique_id = f"{row['entry_id']}_{idx.value}"

            func_call = FunctionCall(
                entry_id=unique_id,
                function_name=row['label'],
                start_time=idx,
                end_time=row['end_time'],
                parent_id=str(row['parent_id']),
                thread_id=str(row['entry_name'])
            )

            self.function_calls[unique_id] = func_call
            self.thread_calls[str(row['entry_name'])].append(func_call)

        # Build parent-child relationships using time-based nesting
        # Since parent_id seems to be mostly 0.0, we'll infer hierarchy from temporal containment
        self._build_temporal_hierarchy()

        # Sort children by start time
        for func_call in self.function_calls.values():
            func_call.children.sort(key=lambda x: x.start_time)

        self.logger.info(f"Built hierarchy with {len(self.function_calls)} function calls across {len(self.thread_calls)} threads")

    def _build_temporal_hierarchy(self):
        """Build hierarchy based on temporal containment within each thread"""
        for thread_id, calls in self.thread_calls.items():
            if not calls:
                continue

            # Sort calls by start time
            calls.sort(key=lambda x: x.start_time)

            # Use a stack to track the call hierarchy
            call_stack = []

            for call in calls:
                # Pop completed calls from stack
                while call_stack and call_stack[-1].end_time <= call.start_time:
                    call_stack.pop()

                if call_stack:
                    # This call is nested within the top of the stack
                    parent = call_stack[-1]
                    parent.children.append(call)
                else:
                    # This is a root call
                    self.root_calls[thread_id].append(call)

                # Add depth to the call
                call.depth = len(call_stack)

                # Add current call to stack
                call_stack.append(call)

    def _find_critical_path_per_thread(self) -> Dict[str, Tuple[List[FunctionCall], int]]:
        """Find critical path for each thread"""
        thread_critical_paths = {}

        for thread_id, root_calls in self.root_calls.items():
            if not root_calls:
                continue

            max_duration = 0
            critical_path = []

            for root_call in root_calls:
                path, duration = self._find_longest_path_from_node(root_call)
                if duration > max_duration:
                    max_duration = duration
                    critical_path = path

            thread_critical_paths[thread_id] = (critical_path, max_duration)

        return thread_critical_paths

    def _find_longest_path_from_node(self, node: FunctionCall) -> Tuple[List[FunctionCall], int]:
        """Find the longest path starting from a given node using DFS - FINAL CORRECTED VERSION"""
        if not node.children:
            # Leaf node: return just this node and its wall-clock duration
            return [node], node.duration_ns

        max_child_duration = 0
        best_child_path = []

        for child in node.children:
            child_path, child_duration = self._find_longest_path_from_node(child)
            if child_duration > max_child_duration:
                max_child_duration = child_duration
                best_child_path = child_path

        # FINAL CORRECTION: For critical path, we want the TOTAL wall-clock time
        # The critical path duration is the root node's total duration
        # The path shows the sequence through the longest nested branch
        return [node] + best_child_path, node.duration_ns

    def _find_global_critical_path(self) -> Tuple[List[FunctionCall], int, str]:
        """Find the global critical path across all threads - CORRECTED VERSION"""
        thread_paths = self._find_critical_path_per_thread()

        max_duration = 0
        global_critical_path = []
        critical_thread = ""

        for thread_id, (path, duration) in thread_paths.items():
            if duration > max_duration:
                max_duration = duration
                global_critical_path = path
                critical_thread = thread_id

        return global_critical_path, max_duration, critical_thread

    def _analyze_bottlenecks(self, critical_path: List[FunctionCall]) -> Dict:
        """Analyze bottlenecks in the critical path (handling recursion correctly)"""
        if not critical_path:
            return {}

        total_duration = sum(call.duration_ns for call in critical_path)

        function_durations = defaultdict(int)
        function_counts = defaultdict(int)
        function_self_times = defaultdict(int)

        for call in critical_path:
            # Use entry_id to disambiguate recursive calls (optional)
            key = (call.function_name, call.entry_id)
            function_durations[key] += call.duration_ns
            function_counts[key] += 1
            function_self_times[key] += call.self_time_ns

        bottleneck_analysis = []
        sorted_functions = sorted(function_durations.items(), key=lambda x: x[1], reverse=True)

        for (func_name, entry_id), total_dur in sorted_functions[:20]:
            count = function_counts[(func_name, entry_id)]
            avg_dur = total_dur / count
            self_time = function_self_times[(func_name, entry_id)]
            percentage = (total_dur / total_duration) * 100

            bottleneck_analysis.append({
                'function': func_name,
                'entry_id': entry_id,
                'total_duration_ns': total_dur,
                'total_duration_us': total_dur / 1000,
                'count': count,
                'avg_duration_ns': avg_dur,
                'avg_duration_us': avg_dur / 1000,
                'self_time_ns': self_time,
                'self_time_us': self_time / 1000,
                'percentage': percentage
            })

        return {
            'total_duration_ns': total_duration,
            'total_duration_us': total_duration / 1000,
            'path_length': len(critical_path),
            'bottlenecks': bottleneck_analysis,
            'critical_path': critical_path
        }

    def _get_function_statistics(self) -> pd.DataFrame:
        """Get comprehensive function statistics"""
        stats = []

        for func_call in self.function_calls.values():
            stats.append({
                'function_name': func_call.function_name,
                'thread_id': func_call.thread_id,
                'start_time': func_call.start_time,
                'end_time': func_call.end_time,
                'duration_ns': func_call.duration_ns,
                'duration_us': func_call.duration_us,
                'self_time_ns': func_call.self_time_ns,
                'num_children': len(func_call.children),
                'entry_id': func_call.entry_id,
                'parent_id': func_call.parent_id
            })

        return pd.DataFrame(stats)

    def _find_hotspot_functions(self, top_n: int = 20) -> pd.DataFrame:
        """Find functions that consume the most time (handle recursion by call identity)"""
        stats_df = self._get_function_statistics()

        if stats_df.empty:
            return pd.DataFrame()

        # Group by both function name and optionally entry ID to disambiguate recursion
        group_cols = ['function_name']  # change to ['function_name', 'entry_id'] to disambiguate
        hotspots = stats_df.groupby(group_cols).agg({
            'duration_ns': ['sum', 'mean', 'count', 'max'],
            'self_time_ns': ['sum', 'mean'],
            'num_children': 'mean'
        }).round(2)

        hotspots.columns = [f"{col[0]}_{col[1]}" if col[1] else col[0]
                            for col in hotspots.columns]

        total_time = stats_df['duration_ns'].sum()
        hotspots['percentage_total_time'] = (
            hotspots['duration_ns_sum'] / total_time * 100).round(2)

        hotspots = hotspots.sort_values('duration_ns_sum', ascending=False).head(top_n)
        hotspots['duration_us_sum'] = (hotspots['duration_ns_sum'] / 1000).round(2)
        hotspots['duration_us_mean'] = (hotspots['duration_ns_mean'] / 1000).round(2)
        hotspots['self_time_us_sum'] = (hotspots['self_time_ns_sum'] / 1000).round(2)

        return hotspots.reset_index()

    def _visualize_critical_path(self, critical_path: List[FunctionCall],
                                 top_n: int = 50, figsize: Tuple[int, int] = (16, 10), **kwargs):
        """Visualize the critical path as a timeline showing function execution sequence"""
        if not critical_path:
            self.logger.warning("No critical path to visualize")
            return None

        # Limit to top_n functions for readability
        path_to_visualize = critical_path[:top_n]

        # Calculate relative timing - use the first function's start as time zero
        start_time_ref = path_to_visualize[0].start_time

        # Prepare timeline data
        timeline_data = []
        for i, call in enumerate(path_to_visualize):
            # Calculate relative start and end times in microseconds
            rel_start = (call.start_time - start_time_ref).total_seconds() * 1e6
            rel_end = (call.end_time - start_time_ref).total_seconds() * 1e6

            # Truncate function name for display
            func_display = call.function_name
            if len(func_display) > 60:
                func_display = func_display[:57] + "..."

            timeline_data.append({
                'depth': i,
                'function': func_display,
                'start_us': rel_start,
                'end_us': rel_end,
                'duration_us': call.duration_us,
                'self_time_us': call.self_time_ns / 1000
            })

        # Create the timeline visualization
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=figsize, height_ratios=[3, 1], dpi=kwargs.get("dpi", 100))

        # Main timeline plot - showing critical path execution flow
        colors = plt.cm.plasma(np.linspace(0.1, 0.9, len(timeline_data)))

        # Plot each function call as a horizontal bar
        for i, data in enumerate(timeline_data):
            # Main duration bar
            bar = ax1.barh(i, data['end_us'] - data['start_us'], left=data['start_us'],
                           height=0.6, color=colors[i], alpha=0.9,
                           edgecolor='black', linewidth=0.5)

            # Add function name and duration annotation
            ax1.text(data['start_us'] + data['duration_us']/2, i,
                     f"{data['function']} - {self._format_time_with_unit(data['duration_us'] * 1000)}",
                     ha='center', va='center', fontsize=8,
                     bbox=dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.9))

        # Add arrows to better visualize the invokation of functions from it's parent function
        # It should be an arrow from the parent function to the beginnig of the child function
        for i, data in enumerate(timeline_data):
            if i > 0:
                parent_y = i - 1 + 0.3
                child_y = i - 0.3

                # From parent to child start
                ax1.annotate('', xy=(data['start_us'], child_y), xytext=(data['start_us'], parent_y),
                             arrowprops=dict(arrowstyle='->', color='black', lw=0.7))

                # From child end to parent
                ax1.annotate('', xy=(data['end_us'], parent_y), xytext=(data['end_us'], child_y),
                    arrowprops=dict(arrowstyle='->', color='black', lw=0.7))

        # Determine best time unit for axis labels
        max_time = max(data['end_us'] for data in timeline_data) if timeline_data else 0
        time_factor, time_unit = self._get_best_time_unit_for_range(max_time)

        # Format the main timeline
        ax1.set_yticks(range(len(timeline_data)))
        ax1.set_yticklabels([f"Call {i+1}" for i in range(len(timeline_data))])
        ax1.set_xlabel(f'Time ({time_unit} from start)')
        ax1.set_ylabel('Critical Path Sequence')
        ax1.set_title('Critical Path Timeline - Function Execution Sequence')
        ax1.grid(True, alpha=0.3, axis='x')
        ax1.invert_yaxis()  # So the first call appears at the top

        # Add a small dynamic left padding to the x-axis, so the first function is not sticking to the left edge
        data_min = min(data['start_us'] for data in timeline_data) if timeline_data else 0
        data_range = max(data['end_us'] for data in timeline_data) - data_min if timeline_data else 1
        left_pad = max(data_range * 0.02, 1)  # 2% of range or at least 1 unit
        ax1.set_xlim(left=data_min - left_pad)

        # Update x-axis tick labels to use appropriate units
        if time_factor != 1:
            x_ticks = ax1.get_xticks()
            ax1.set_xticks(x_ticks)
            ax1.set_xticklabels([f'{tick * time_factor:.1f}' for tick in x_ticks])

        # Add total execution time annotation
        total_time = timeline_data[0]['duration_us']
        ax1.text(0.02, 0.98, f'Total Critical Path Time: {self._format_time_with_unit(total_time * 1000)}',
                 transform=ax1.transAxes, verticalalignment='top',
                 bbox=dict(boxstyle="round,pad=0.3", facecolor='yellow', alpha=0.8))

        # Bottom plot - Cumulative time progression
        cumulative_times = []
        function_names = []

        for i, data in enumerate(timeline_data[:15]):
            # Time elapsed from program start to when this function begins
            elapsed_time = data['start_us']
            cumulative_times.append(elapsed_time)
            function_names.append(data['function'])

        x_pos = np.arange(len(cumulative_times))
        bars = ax2.bar(x_pos, cumulative_times, alpha=0.8, color='teal')

        # Add value labels on bars
        for i, (bar, time) in enumerate(zip(bars, cumulative_times)):
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height,
                     f'{self._format_time_with_unit(time * 1000)}', ha='center', va='bottom', fontsize=8)

        ax2.set_xticks(x_pos)
        ax2.set_xticklabels(function_names, rotation=45, ha='right', fontsize=7)
        # Use the same time unit as the main chart for consistency
        ax2.set_ylabel(f'Cumulative Time ({time_unit})')
        ax2.set_title('Cumulative Execution Time Along Critical Path')
        ax2.grid(True, alpha=0.3, axis='y')

        # Update y-axis tick labels to use appropriate units
        if time_factor != 1:
            y_ticks = ax2.get_yticks()
            ax2.set_yticks(y_ticks)
            ax2.set_yticklabels([f'{tick * time_factor:.1f}' for tick in y_ticks])

        plt.tight_layout()

        return fig

    def get_critical_path(self, include_hotspots: bool = False,
                          top_bottlenecks: int = 10) -> Dict:
        """
        Get the critical path analysis results.

        This is the main public method that returns comprehensive critical path analysis.

        :param include_hotspots: Whether to include global function hotspots analysis
        :type include_hotspots: bool
        :param top_bottlenecks: Number of top bottlenecks to include in results
        :type top_bottlenecks: int
        :return: Dictionary containing critical path analysis results
        :rtype: Dict
        """
        if self.flamechart is None:
            self.logger.error("No flame chart data available. Ensure the module has been properly initialized.")
            return {}

        if not self.function_calls:
            self.logger.error("No function calls processed. Check if the flame chart data is valid.")
            return {}

        self.logger.info("Computing critical path analysis...")

        try:
            # Find global critical path
            critical_path, total_duration, critical_thread = self._find_global_critical_path()

            if not critical_path:
                self.logger.warning("No critical path found")
                return {'error': 'No critical path found'}

            # Analyze bottlenecks
            bottleneck_analysis = self._analyze_bottlenecks(critical_path)

            # Get per-thread analysis
            thread_paths = self._find_critical_path_per_thread()

            # Prepare results
            results = {
                'summary': {
                    'critical_thread': critical_thread,
                    'total_duration_ns': total_duration,
                    'total_duration_us': total_duration / 1000,
                    'total_duration_ms': total_duration / 1_000_000,
                    'path_length': len(critical_path),
                    'num_threads': len(thread_paths),
                    'total_function_calls': len(self.function_calls)
                },
                'critical_path': {
                    'functions': [
                        {
                            'function_name': call.function_name,
                            'duration_ns': call.duration_ns,
                            'duration_us': call.duration_us,
                            'self_time_ns': call.self_time_ns,
                            'start_time': call.start_time,
                            'end_time': call.end_time,
                            'thread_id': call.thread_id,
                            'entry_id': call.entry_id
                        }
                        for call in critical_path
                    ]
                },
                'bottlenecks': bottleneck_analysis['bottlenecks'][:top_bottlenecks],
                'thread_analysis': {
                    thread_id: {
                        'duration_ns': duration,
                        'duration_us': duration / 1000,
                        'path_length': len(path),
                        'functions': [call.function_name for call in path[:5]]  # Top 5 functions
                    }
                    for thread_id, (path, duration) in thread_paths.items()
                }
            }

            # Add hotspots if requested
            if include_hotspots:
                hotspots = self._find_hotspot_functions(top_n=20)
                if not hotspots.empty:
                    results['hotspots'] = hotspots.to_dict('index')

            # Cache results
            self._analysis_results = results

            self.logger.info(f"Critical path analysis completed. Found path with {len(critical_path)} functions "
                             f"spanning {self._format_time_with_unit(total_duration)}")

            return results

        except Exception as e:
            self.logger.error(f"Error during critical path analysis: {e}")
            return {'error': str(e)}

    def get_function_statistics(self) -> pd.DataFrame:
        """
        Get detailed statistics for all functions.

        :return: DataFrame with comprehensive function statistics
        :rtype: pd.DataFrame
        """
        return self._get_function_statistics()

    def get_hotspot_functions(self, top_n: int = 20) -> pd.DataFrame:
        """
        Get the most time-consuming functions across all threads.

        :param top_n: Number of top functions to return
        :type top_n: int
        :return: DataFrame with hotspot function analysis
        :rtype: pd.DataFrame
        """
        return self._find_hotspot_functions(top_n)

    def visualize_critical_path(self, **kwargs):
        """
        Generate and display critical path visualization.

        :param kwargs: Additional visualization parameters
        :return: Matplotlib figure object
        """
        if self._analysis_results is None:
            self.get_critical_path()

        if self._analysis_results and 'critical_path' in self._analysis_results:
            # Reconstruct FunctionCall objects from results for visualization
            critical_path = []
            for func_data in self._analysis_results['critical_path']['functions']:
                call = FunctionCall(
                    entry_id=func_data['entry_id'],
                    function_name=func_data['function_name'],
                    start_time=func_data['start_time'],
                    end_time=func_data['end_time'],
                    parent_id="",
                    thread_id=func_data['thread_id']
                )
                critical_path.append(call)

            self._visualize_critical_path(critical_path, **kwargs)
