from dataclasses import dataclass
from enum import Enum, auto
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Any, Tuple
from scipy import stats
import matplotlib.pyplot as plt

from tmll.ml.modules.base_module import BaseModule
from tmll.common.models.experiment import Experiment
from tmll.common.models.output import Output
from tmll.tmll_client import TMLLClient
from tmll.ml.utils.document_generator import DocumentGenerator


class ResourceType(Enum):
    """Resource types that can be monitored for bottlenecks"""
    CPU = auto()
    MEMORY = auto()
    DISK = auto()
    NETWORK = auto()


class RiskLevel(Enum):
    """Risk levels for bottleneck detection"""
    LOW = auto()       # 0-40
    MODERATE = auto()  # 40-70
    HIGH = auto()      # 70-100


@dataclass
class BaselineStats:
    """Statistics for historical baseline data"""
    mean: float
    std_dev: float
    percentiles: Dict[int, float]
    peak: float
    typical_range: Tuple[float, float]


@dataclass
class ResourceMetrics:
    """Comprehensive metrics for a specific resource"""
    current_usage: float
    historical_usage: pd.Series
    baseline_stats: BaselineStats
    deviation_score: float
    performance_correlation: float
    bottleneck_score: float
    risk_level: RiskLevel
    unit: str


@dataclass
class PerformanceMetrics:
    """System performance metrics"""
    latency: pd.Series
    throughput: Optional[pd.Series] = None
    queue_length: Optional[pd.Series] = None


@dataclass
class BottleneckAnalysisResult:
    """Results from advanced bottleneck analysis"""
    resources: Dict[ResourceType, ResourceMetrics]
    analysis_period: Dict[str, Optional[pd.Timestamp]]
    performance_metrics: PerformanceMetrics
    primary_bottleneck: ResourceType
    bottleneck_timeline: Dict[ResourceType, pd.Series]
    correlation_matrix: pd.DataFrame


class AdvancedBottleneckDetector(BaseModule):
    """
    Advanced Bottleneck Detector Module

    This module implements a sophisticated approach to bottleneck detection that goes
    beyond simple threshold-based analysis. It incorporates:
    - Historical baseline comparison
    - Performance correlation analysis
    - Multi-resource weighted scoring
    - Time-series bottleneck analysis
    
    The module helps identify true bottlenecks by considering:
    1. How current usage deviates from historical norms
    2. How strongly resource usage correlates with performance degradation
    3. The combined impact of multiple resource constraints
    """

    BASE_OUTPUTS = [
        Output.from_dict({
            "name": "CPU Usage",
            "id": "org.eclipse.tracecompass.analysis.os.linux.core.cpuusage.CpuUsageDataProvider"
        }),
        Output.from_dict({
            "name": "Memory Usage",
            "id": "org.eclipse.tracecompass.analysis.os.linux.core.kernelmemoryusage"
        }),
        Output.from_dict({
            "name": "Disk I/O",
            "id": "org.eclipse.tracecompass.analysis.os.linux.core.inputoutput.DisksIODataProvider"
        }),
        Output.from_dict({
            "name": "System Call Latency",
            "id": "org.eclipse.tracecompass.internal.analysis.timing.core.segmentstore.scatter.dataprovider:org.eclipse.tracecompass.analysis.os.linux.latency.syscall"
        })
    ]

    def __init__(self, client: TMLLClient, experiment: Experiment,
                 outputs: Optional[List[Output]] = None, **kwargs) -> None:
        """
        Initialize the advanced bottleneck detector.

        :param client: The TMLL client for data communication
        :type client: TMLLClient
        :param experiment: The experiment to analyze
        :type experiment: Experiment
        :param outputs: Optional list of outputs to analyze
        :type outputs: Optional[List[Output]]
        :param kwargs: Additional keyword arguments
        :type kwargs: dict
        """
        super().__init__(client, experiment)
        
        self.historical_baselines: Dict[ResourceType, BaselineStats] = {}
        self.current_data: Dict[ResourceType, pd.DataFrame] = {}
        self.performance_data: Optional[PerformanceMetrics] = None
        
        # Weights for bottleneck score calculation
        self.deviation_weight = kwargs.get('deviation_weight', 0.5)
        self.correlation_weight = kwargs.get('correlation_weight', 0.5)
        
        self.logger.info("Initializing Advanced Bottleneck Detector module")
        
        self._process(outputs or self.BASE_OUTPUTS, **kwargs)

    def _process(self, outputs: Optional[List[Output]] = None, **kwargs) -> None:
        """Process the raw data for bottleneck analysis"""
        super()._process(outputs=outputs,
                         normalize=False,
                         resample=True,
                         align_timestamps=True,
                         **kwargs)

    def _post_process(self, **kwargs) -> None:
        """Post-process the data and organize by resource type"""
        if not self.dataframes:
            return

        # Map dataframes to resource types and extract performance metrics
        for name, df in self.dataframes.items():
            if "cpu" in name.lower():
                self.current_data[ResourceType.CPU] = df
            elif "memory" in name.lower():
                self.current_data[ResourceType.MEMORY] = df
            elif "disk" in name.lower():
                self.current_data[ResourceType.DISK] = df
            elif "network" in name.lower():
                self.current_data[ResourceType.NETWORK] = df
            elif "latency" in name.lower():
                if self.performance_data is None:
                    self.performance_data = PerformanceMetrics(
                        latency=df[df.columns[0]]
                    )

    def _calculate_baseline_stats(self, historical_data: pd.Series) -> BaselineStats:
        """
        Calculate baseline statistics from historical data.

        :param historical_data: Historical time series data
        :type historical_data: pd.Series
        :return: Baseline statistics
        :rtype: BaselineStats
        """
        return BaselineStats(
            mean=historical_data.mean(),
            std_dev=historical_data.std(),
            percentiles={
                25: historical_data.quantile(0.25),
                50: historical_data.quantile(0.50),
                75: historical_data.quantile(0.75),
                90: historical_data.quantile(0.90),
                95: historical_data.quantile(0.95)
            },
            peak=historical_data.max(),
            typical_range=(
                historical_data.mean() - 2 * historical_data.std(),
                historical_data.mean() + 2 * historical_data.std()
            )
        )

    def _calculate_deviation_score(self, current: float,
                                 baseline: BaselineStats,
                                 epsilon: float = 1e-6) -> float:
        """
        Calculate how much current usage deviates from baseline.

        :param current: Current usage value
        :type current: float
        :param baseline: Baseline statistics
        :type baseline: BaselineStats
        :param epsilon: Small value to avoid division by zero
        :type epsilon: float
        :return: Deviation score
        :rtype: float
        """
        return (current - baseline.mean) / (baseline.std_dev + epsilon)

    def _calculate_performance_correlation(self, resource_usage: pd.Series,
                                        performance_metrics: PerformanceMetrics,
                                        method: str = 'spearman') -> float:
        """
        Calculate correlation between resource usage and performance degradation.

        :param resource_usage: Resource usage time series
        :type resource_usage: pd.Series
        :param performance_metrics: Performance metrics
        :type performance_metrics: PerformanceMetrics
        :param method: Correlation method ('pearson' or 'spearman')
        :type method: str
        :return: Correlation coefficient
        :rtype: float
        """
        if method == 'pearson':
            corr, _ = stats.pearsonr(resource_usage, performance_metrics.latency)
        else:  # spearman
            corr, _ = stats.spearmanr(resource_usage, performance_metrics.latency)
        return corr # type: ignore

    def _calculate_bottleneck_score(self, deviation_score: float,
                                  performance_correlation: float) -> float:
        """
        Calculate weighted bottleneck score.

        :param deviation_score: Deviation from baseline score
        :type deviation_score: float
        :param performance_correlation: Correlation with performance
        :type performance_correlation: float
        :return: Bottleneck score (0-100)
        :rtype: float
        """
        # Normalize deviation score to 0-1 range
        norm_deviation = (np.clip(deviation_score, -3, 3) + 3) / 6
        # Normalize correlation to 0-1 range
        norm_correlation = (performance_correlation + 1) / 2
        
        # Calculate weighted score
        score = (self.deviation_weight * norm_deviation +
                self.correlation_weight * norm_correlation) * 100
        
        return np.clip(score, 0, 100)

    def _determine_risk_level(self, bottleneck_score: float) -> RiskLevel:
        """
        Determine risk level based on bottleneck score.

        :param bottleneck_score: Calculated bottleneck score
        :type bottleneck_score: float
        :return: Risk level
        :rtype: RiskLevel
        """
        if bottleneck_score < 40:
            return RiskLevel.LOW
        elif bottleneck_score < 70:
            return RiskLevel.MODERATE
        else:
            return RiskLevel.HIGH

    def analyze_bottlenecks(self, start_time: Optional[pd.Timestamp] = None,
                          end_time: Optional[pd.Timestamp] = None,
                          window_size: str = '30s') -> BottleneckAnalysisResult:
        """
        Perform advanced bottleneck analysis using historical baselines and
        performance correlation.

        :param start_time: Start time for analysis
        :type start_time: Optional[pd.Timestamp]
        :param end_time: End time for analysis
        :type end_time: Optional[pd.Timestamp]
        :param window_size: Size of sliding window for analysis
        :type window_size: str
        :return: Advanced bottleneck analysis results
        :rtype: BottleneckAnalysisResult
        """
        resources: Dict[ResourceType, ResourceMetrics] = {}
        bottleneck_timeline: Dict[ResourceType, pd.Series] = {}
        correlation_matrix = pd.DataFrame()

        # Calculate baseline stats if not already available
        for resource_type, df in self.current_data.items():
            if resource_type not in self.historical_baselines:
                self.historical_baselines[resource_type] = self._calculate_baseline_stats(
                    df[df.columns[0]]
                )

        # Analyze each resource
        for resource_type, df in self.current_data.items():
            if df.empty:
                continue

            # Filter by time period if specified
            if start_time and end_time:
                df = df[(df.index >= start_time) & (df.index <= end_time)]

            # Get the primary metric column
            metric_series = df[df.columns[0]]
            current = metric_series.iloc[-1]

            # Calculate deviation and correlation
            baseline = self.historical_baselines[resource_type]
            deviation = self._calculate_deviation_score(current, baseline)
            
            correlation = 0.0
            if self.performance_data:
                correlation = self._calculate_performance_correlation(
                    metric_series,
                    self.performance_data
                )

            # Calculate bottleneck score
            score = self._calculate_bottleneck_score(deviation, correlation)
            
            # Store results
            resources[resource_type] = ResourceMetrics(
                current_usage=current,
                historical_usage=metric_series,
                baseline_stats=baseline,
                deviation_score=deviation,
                performance_correlation=correlation,
                bottleneck_score=score,
                risk_level=self._determine_risk_level(score),
                unit="%" if resource_type in [ResourceType.CPU, ResourceType.MEMORY]
                     else "MB/s"
            )

            # Calculate timeline of bottleneck scores
            rolling_scores = metric_series.rolling(window=window_size).apply(
                lambda x: self._calculate_bottleneck_score(
                    self._calculate_deviation_score(x.mean(), baseline),
                    correlation
                )
            )
            bottleneck_timeline[resource_type] = rolling_scores

        # Determine primary bottleneck
        primary_bottleneck = max(
            resources.items(),
            key=lambda x: x[1].bottleneck_score
        )[0]

        # Create correlation matrix
        corr_data = {}
        for r_type, metrics in resources.items():
            corr_data[r_type.name] = metrics.historical_usage
        if self.performance_data:
            corr_data['Latency'] = self.performance_data.latency
        correlation_matrix = pd.DataFrame(corr_data).corr()

        return BottleneckAnalysisResult(
            resources=resources,
            analysis_period={"start": start_time, "end": end_time},
            performance_metrics=self.performance_data if self.performance_data is not None else PerformanceMetrics(latency=pd.Series(dtype=float)),
            primary_bottleneck=primary_bottleneck,
            bottleneck_timeline=bottleneck_timeline,
            correlation_matrix=correlation_matrix
        )

    def interpret(self, analysis_result: BottleneckAnalysisResult) -> None:
        """
        Interpret and display advanced bottleneck analysis results.

        :param analysis_result: Results from bottleneck analysis
        :type analysis_result: BottleneckAnalysisResult
        """
        DocumentGenerator.section("Advanced Bottleneck Analysis Results")

        # Analysis period
        period_metrics = {
            "Start Time": analysis_result.analysis_period["start"].strftime("%Y-%m-%d %H:%M:%S")
                if analysis_result.analysis_period["start"] else "N/A",
            "End Time": analysis_result.analysis_period["end"].strftime("%Y-%m-%d %H:%M:%S")
                if analysis_result.analysis_period["end"] else "N/A"
        }
        DocumentGenerator.metrics_group("Analysis Period", period_metrics)

        # Primary bottleneck alert
        primary_metrics = analysis_result.resources[analysis_result.primary_bottleneck]
        if primary_metrics.risk_level in [RiskLevel.MODERATE, RiskLevel.HIGH]:
            bottleneck_alert = {
                "Primary Bottleneck": analysis_result.primary_bottleneck.name,
                "Risk Level": primary_metrics.risk_level.name,
                "Bottleneck Score": f"{primary_metrics.bottleneck_score:.1f}/100",
                "Current Usage": f"{primary_metrics.current_usage:.1f}{primary_metrics.unit}",
                "Deviation from Baseline": f"{primary_metrics.deviation_score:.2f}σ",
                "Performance Correlation": f"{primary_metrics.performance_correlation:.2f}"
            }
            DocumentGenerator.metrics_group("⚠️ Primary Bottleneck Alert", bottleneck_alert)

        # Resource analysis
        for resource_type, metrics in analysis_result.resources.items():
            resource_metrics = {
                "Current Usage": f"{metrics.current_usage:.1f}{metrics.unit}",
                "Bottleneck Score": f"{metrics.bottleneck_score:.1f}/100",
                "Risk Level": metrics.risk_level.name,
                "Baseline Mean": f"{metrics.baseline_stats.mean:.1f}{metrics.unit}",
                "Baseline Peak": f"{metrics.baseline_stats.peak:.1f}{metrics.unit}",
                "Current Deviation": f"{metrics.deviation_score:.2f}σ",
                "Performance Impact": f"Correlation: {metrics.performance_correlation:.2f}"
            }
            DocumentGenerator.metrics_group(f"Resource Analysis: {resource_type.name}", resource_metrics)

        # Performance correlation analysis
        if analysis_result.correlation_matrix is not None:
            correlation_headers = ["Resource", "Latency Correlation"]
            correlation_rows = []
            for resource_type in ResourceType:
                if resource_type.name in analysis_result.correlation_matrix.columns:
                    corr = analysis_result.correlation_matrix.loc[resource_type.name, "Latency"]
                    correlation_rows.append([
                        resource_type.name,
                        f"{corr:.3f}"
                    ])
            DocumentGenerator.table(
                correlation_headers,
                correlation_rows,
                "Resource-Performance Correlations"
            )

        # Recommendations
        self._generate_recommendations(analysis_result)

    def _generate_recommendations(self, analysis_result: BottleneckAnalysisResult) -> None:
        """
        Generate detailed recommendations based on analysis results.

        :param analysis_result: Bottleneck analysis results
        :type analysis_result: BottleneckAnalysisResult
        """
        recommendations = {}

        # Generate recommendations for high-risk resources
        for resource_type, metrics in analysis_result.resources.items():
            if metrics.risk_level in [RiskLevel.MODERATE, RiskLevel.HIGH]:
                recommendations[f"{resource_type.name} Optimization"] = self._get_resource_recommendations(
                    resource_type,
                    metrics
                )

        # Add general recommendations if needed
        if len(recommendations) > 1:
            recommendations["General Recommendations"] = (
                "Multiple resources show signs of stress. Consider:\n"
                "- Reviewing system architecture for better resource distribution\n"
                "- Implementing horizontal scaling\n"
                "- Monitoring resource usage patterns over longer periods"
            )

        if recommendations:
            DocumentGenerator.metrics_group("Recommendations", recommendations)

    def _get_resource_recommendations(self, resource_type: ResourceType,
                                    metrics: ResourceMetrics) -> str:
        """
        Get specific recommendations for a resource.

        :param resource_type: Type of resource
        :type resource_type: ResourceType
        :param metrics: Resource metrics
        :type metrics: ResourceMetrics
        :return: Recommendation string
        :rtype: str
        """
        base_msg = (
            f"Resource is showing {metrics.risk_level.name.lower()} risk "
            f"(Score: {metrics.bottleneck_score:.1f}/100)\n"
        )

        if resource_type == ResourceType.CPU:
            return base_msg + (
                "Recommended actions:\n"
                "- Profile CPU-intensive processes\n"
                "- Consider thread pool optimization\n"
                "- Evaluate CPU scaling options\n"
                "- Look for opportunities to parallelize workloads"
            )
        elif resource_type == ResourceType.MEMORY:
            return base_msg + (
                "Recommended actions:\n"
                "- Check for memory leaks\n"
                "- Review memory allocation patterns\n"
                "- Consider implementing caching\n"
                "- Optimize large object lifecycles"
            )
        elif resource_type == ResourceType.DISK:
            return base_msg + (
                "Recommended actions:\n"
                "- Analyze I/O patterns\n"
                "- Consider implementing buffering\n"
                "- Evaluate disk striping options\n"
                "- Review filesystem performance"
            )
        else:  # Network
            return base_msg + (
                "Recommended actions:\n"
                "- Review network topology\n"
                "- Implement request batching\n"
                "- Consider data compression\n"
                "- Evaluate connection pooling"
            )

    def plot(self, analysis_result: BottleneckAnalysisResult, **kwargs) -> None:
        """
        Create comprehensive visualizations of bottleneck analysis results.

        :param analysis_result: Results from bottleneck analysis
        :type analysis_result: BottleneckAnalysisResult
        :param kwargs: Additional plotting parameters
        :type kwargs: dict
        """
        fig_size = kwargs.get("fig_size", (12, 8))
        fig_dpi = kwargs.get("fig_dpi", 100)

        # 1. Radar Chart of Bottleneck Scores
        self._plot_bottleneck_radar(analysis_result, fig_size, fig_dpi)

        # 2. Time Series of Resource Usage vs Baselines
        self._plot_resource_timelines(analysis_result, fig_size, fig_dpi)

        # 3. Correlation Matrix Heatmap
        self._plot_correlation_heatmap(analysis_result, fig_size, fig_dpi)

        # 4. Bottleneck Score Timeline
        self._plot_bottleneck_timeline(analysis_result, fig_size, fig_dpi)

    def _plot_bottleneck_radar(self, analysis_result: BottleneckAnalysisResult,
                              fig_size: Tuple[float, float], fig_dpi: int) -> None:
        """
        Plot radar chart of bottleneck scores.

        :param analysis_result: Bottleneck analysis results
        :type analysis_result: BottleneckAnalysisResult
        :param fig_size: Figure size
        :type fig_size: Tuple[float, float]
        :param fig_dpi: Figure DPI
        :type fig_dpi: int
        """
        angles = np.linspace(0, 2*np.pi, len(ResourceType), endpoint=False)
        values = []
        labels = []

        for resource_type in ResourceType:
            if resource_type in analysis_result.resources:
                values.append(analysis_result.resources[resource_type].bottleneck_score)
                labels.append(resource_type.name)

        # Close the plot
        values.append(values[0])
        angles = np.concatenate((angles, [angles[0]]))

        radar_data = pd.DataFrame({
            'angle': angles,
            'value': values
        })

        plots = [{
            'plot_type': 'radar',
            'data': radar_data,
            'values': values,
            'labels': labels,
            'color': 'blue',
            'fill': True,
            'alpha': 0.25
        }]

        self._plot(plots, plot_size=fig_size, dpi=fig_dpi,
                  fig_title="Resource Bottleneck Radar",
                  fig_xlabel="Resources",
                  fig_ylabel="Bottleneck Score")

    def _plot_resource_timelines(self, analysis_result: BottleneckAnalysisResult,
                               fig_size: Tuple[float, float], fig_dpi: int) -> None:
        """
        Plot time series of resource usage with baselines.

        :param analysis_result: Bottleneck analysis results
        :type analysis_result: BottleneckAnalysisResult
        :param fig_size: Figure size
        :type fig_size: Tuple[float, float]
        :param fig_dpi: Figure DPI
        :type fig_dpi: int
        """
        for resource_type, metrics in analysis_result.resources.items():
            plots = []
            
            # Current usage
            plots.append({
                'plot_type': 'time_series',
                'data': pd.DataFrame({
                    'usage': metrics.historical_usage
                }),
                'y': 'usage',
                'label': f'{resource_type.name} Usage',
                'color': 'blue',
                'alpha': 0.8
            })

            # Baseline mean
            plots.append({
                'plot_type': 'hline',
                'y': metrics.baseline_stats.mean,
                'label': 'Baseline Mean',
                'color': 'green',
                'linestyle': '--',
                'alpha': 0.5
            })

            # Baseline range
            plots.append({
                'plot_type': 'fill_between',
                'data': pd.DataFrame({
                    'y1': [metrics.baseline_stats.typical_range[0]] * len(metrics.historical_usage),
                    'y2': [metrics.baseline_stats.typical_range[1]] * len(metrics.historical_usage)
                }),
                'label': 'Typical Range',
                'color': 'green',
                'alpha': 0.2
            })

            self._plot(plots, plot_size=fig_size, dpi=fig_dpi,
                      fig_title=f"{resource_type.name} Usage Timeline",
                      fig_xlabel="Time",
                      fig_ylabel=f"Usage ({metrics.unit})")

    def _plot_correlation_heatmap(self, analysis_result: BottleneckAnalysisResult,
                                fig_size: Tuple[float, float], fig_dpi: int) -> None:
        """
        Plot correlation matrix heatmap.

        :param analysis_result: Bottleneck analysis results
        :type analysis_result: BottleneckAnalysisResult
        :param fig_size: Figure size
        :type fig_size: Tuple[float, float]
        :param fig_dpi: Figure DPI
        :type fig_dpi: int
        """
        plots = [{
            'plot_type': 'heatmap',
            'data': analysis_result.correlation_matrix,
            'cmap': 'RdBu',
            'center': 0,
            'annot': True,
            'fmt': '.2f'
        }]

        self._plot(plots, plot_size=fig_size, dpi=fig_dpi,
                  fig_title="Resource-Performance Correlation Matrix")

    def _plot_bottleneck_timeline(self, analysis_result: BottleneckAnalysisResult,
                                fig_size: Tuple[float, float], fig_dpi: int) -> None:
        """
        Plot timeline of bottleneck scores.

        :param analysis_result: Bottleneck analysis results
        :type analysis_result: BottleneckAnalysisResult
        :param fig_size: Figure size
        :type fig_size: Tuple[float, float]
        :param fig_dpi: Figure DPI
        :type fig_dpi: int
        """
        plots = []
        colors = plt.colormaps.get_cmap('tab10')

        for idx, (resource_type, timeline) in enumerate(analysis_result.bottleneck_timeline.items()):
            plots.append({
                'plot_type': 'time_series',
                'data': pd.DataFrame({'score': timeline}),
                'y': 'score',
                'label': resource_type.name,
                'color': colors(idx),
                'alpha': 0.8
            })

            # Add threshold lines
            plots.extend([
                {
                    'plot_type': 'hline',
                    'y': 40,
                    'color': 'yellow',
                    'linestyle': '--',
                    'alpha': 0.3,
                    'label': 'Moderate Risk'
                },
                {
                    'plot_type': 'hline',
                    'y': 70,
                    'color': 'red',
                    'linestyle': '--',
                    'alpha': 0.3,
                    'label': 'High Risk'
                }
            ])

        self._plot(plots, plot_size=fig_size, dpi=fig_dpi,
                  fig_title="Bottleneck Score Timeline",
                  fig_xlabel="Time",
                  fig_ylabel="Bottleneck Score")